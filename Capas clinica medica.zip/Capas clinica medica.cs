﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClinicaMedica.Capa_Datos
{
    internal class ConexionDB
    {
    }
}
